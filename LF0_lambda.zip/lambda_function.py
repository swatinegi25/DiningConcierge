
import boto3
# Define the client to interact with Lex
client = boto3.client('lexv2-runtime')
def lambda_handler(event, context):
    # msg_from_user = event['messages'][0]
    # change this to the message that user submits on 
    # your website using the 'event' variable
    txt_type = event['messages'][0]['type']
    msg_from_user = event['messages'][0][txt_type]['text']
    print(f"Message from frontend: {msg_from_user}")
    # Initiate conversation with Lex
    response = client.recognize_text(
            botId='2JQMBGS0O5', # MODIFY HERE
            botAliasId='0PCMNHBFKF', # MODIFY HERE
            localeId='en_US',
            sessionId='testuser',
            text=msg_from_user)
    
    msg_from_lex = response.get('messages', [])
    print(msg_from_lex)
    if msg_from_lex:
        
        print(f"Message from Chatbot: {msg_from_lex[0]['content']}")
        print(response)
        resp = {
            'statusCode': 200,
            'body': msg_from_lex[0]['content']
        }
    
        intent = response['sessionState']['intent']
        intent_name = intent['name']
        end = intent['state']
        
        if intent_name == "DiningSuggestionsIntent" and end == "ReadyForFulfillment":
            slots = intent['slots']
            
            cuisine = slots['Cuisine']['value']['interpretedValue']
            location = slots['Location']['value']['interpretedValue']
            date = slots['Dining-Date']['value']['interpretedValue']
            time = slots['Dining-Time']['value']['interpretedValue']
            num_people = slots['Number-of-People']['value']['interpretedValue']
            phone = slots['Phone-Number']['value']['interpretedValue']
            
            print(f"We received this data: {cuisine}, {location}, {phone}")
            
            sqs = boto3.client('sqs')
            
            sqs.send_message(
                QueueUrl='https://sqs.us-east-1.amazonaws.com/608212036408/DiningQueue',
                MessageBody=str({
                    'Cuisine': cuisine,
                    'Location': location,
                    'Date': date,
                    'Time': time,
                    'Number of People': num_people,
                    'Phone Number': phone
                })
                )
            
            # sqs.send_message(QueueUrl='https://sqs.us-east-1.amazonaws.com/608212036408/DiningQueue', MessageBody='Yay!')
        
        # modify resp to send back the next question Lex would ask from the user
        
        # format resp in a way that is understood by the frontend
        # HINT: refer to function insertMessage() in chat.js that you uploaded
        # to the S3 bucket
        return resp
    else:
        print(f"We received nothing from Lex!")
