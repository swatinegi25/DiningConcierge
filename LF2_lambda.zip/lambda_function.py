import json
import boto3
import random

def lambda_handler(event, context):
    # TODO implement
    
    sqs = boto3.client('sqs')
    queue_url='https://sqs.us-east-1.amazonaws.com/608212036408/DiningQueue'
    response = sqs.receive_message(
        QueueUrl=queue_url,
        MaxNumberOfMessages=1
        )
        
    msg = response['Messages'][0]
    receipt_handle = msg['ReceiptHandle']
    
    msg = msg['Body']
    
    # Getting three suggestions from OpenSearch (implemented in opensearch lambda function)
    opensearch = boto3.client('lambda')
    response = opensearch.invoke(
        FunctionName = 'arn:aws:lambda:us-east-1:608212036408:function:opensearch',
        InvocationType = 'RequestResponse',
        Payload = json.dumps(msg)
    )
    
    response = response['Payload'].read().decode("utf-8")
    response = json.loads(response)
    body = json.loads(response["body"])
    results = body["results"]
    selections = results
    
    dynamo = boto3.client('dynamodb')
    msg = json.loads(msg.replace("'", '"'))
    suggestion_str = "Hello! Here are my " + msg["Cuisine"] + " restaurant suggestions for " + msg["Number of People"] + " person(s), for " + msg["Date"] + " at " + msg["Time"] + ": "
    
    for s in selections:
        business_id = s["business_id"]
    
        data = dynamo.get_item(
            TableName="yelp-restaurants",
            Key={
                'BusinessID': {
                    'S': business_id
                }
            }
            )
        
        substr = data["Item"]["Name"]["S"] + ", located at " + data["Item"]["Address"]["S"] + ", "
        suggestion_str += substr
        print(suggestion_str)
        
    sms = boto3.client("sns")
    sms_response = sms.publish(
        PhoneNumber="+1" + msg["Phone Number"],
        Message=suggestion_str
        )
            
    print(sms_response)
    
    sqs.delete_message(
        QueueUrl=queue_url,
        ReceiptHandle=receipt_handle
    )
    

    return {
        'statusCode': 200,
        'body': json.dumps('SMS Sent!')
    }
